const webhookUrl = "http://localhost:5678/webhook/github-code-reviewer";
const reviewForm = document.querySelector("#review-form");
const githubUrlInput = document.querySelector("#github-url");
const reviewButton = reviewForm.querySelector("button[type='submit']");
const validationMessage = document.querySelector("#validation-message");
const stateButtons = document.querySelectorAll("[data-state]");
const statePanels = document.querySelectorAll("[data-state-panel]");
const reviewOutput = document.querySelector("#review-output");
const errorMessage = document.querySelector("#error-message");
const reviewControls = document.querySelectorAll(".review-form input, .review-form button");

function setReviewState(nextState) {
  stateButtons.forEach((button) => {
    const isActive = button.dataset.state === nextState;
    button.classList.toggle("is-active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
  });

  statePanels.forEach((panel) => {
    const isVisible = panel.dataset.statePanel === nextState;
    panel.hidden = !isVisible;
  });

  const isLoading = nextState === "loading";
  reviewControls.forEach((control) => {
    control.disabled = isLoading;
  });

  stateButtons.forEach((button) => {
    button.disabled = isLoading;
  });
}

stateButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setReviewState(button.dataset.state);
  });
});

function showValidationMessage(message) {
  validationMessage.textContent = message;
  validationMessage.hidden = false;
}

function clearValidationMessage() {
  validationMessage.textContent = "";
  validationMessage.hidden = true;
}

function showError(message) {
  errorMessage.textContent = message;
  setReviewState("error");
}

reviewForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearValidationMessage();

  if (!reviewForm.checkValidity()) {
    showValidationMessage("Enter a valid GitHub URL before starting the review.");
    githubUrlInput.focus();
    return;
  }

  reviewOutput.textContent = "";
  setReviewState("loading");

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        githubUrl: githubUrlInput.value.trim()
      })
    });

    if (!response.ok) {
      throw new Error(`The review service returned HTTP ${response.status}.`);
    }

    const responseData = await response.json();
    if (!responseData || typeof responseData.review !== "string" || !responseData.review.trim()) {
      throw new Error("The review service returned an unexpected response.");
    }

    reviewOutput.textContent = responseData.review;
    setReviewState("success");
  } catch (error) {
    const message = error instanceof TypeError
      ? "The review service could not be reached. Check the n8n connection and try again."
      : error.message;
    showError(message);
  } finally {
    reviewControls.forEach((control) => {
      control.disabled = false;
    });
    stateButtons.forEach((button) => {
      button.disabled = false;
    });
  }
});
